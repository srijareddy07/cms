﻿using CIMS_DAL;
using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CIMS_BAL
{
    public class CarBAL
    {
        public static bool IsValid(Car objCar)
        {
            bool valid = true;
            StringBuilder errorMessage = new StringBuilder();
            try
            {
                if ( objCar.ManufacturerName == string.Empty || objCar.Model == string.Empty || objCar.Type == string.Empty|| objCar.Engine==string.Empty || objCar.BHP.ToString()==string.Empty || objCar.Transmission == string.Empty || objCar.Mileage <= 0 || objCar.Seats<= 0 || objCar.AirBagDetails == string.Empty || objCar.BootSpace<=0 || objCar.Colour == string.Empty || objCar.Price<=0 )
                {
                    
                    valid = false;
                    errorMessage.AppendLine("All fields are mandatory");
                }
                if (objCar.Type != "Hatchback" && objCar.Type != "SUV" && objCar.Type != "Sedan")
                {
                    valid = false;
                    errorMessage.AppendLine("Type name should be Hatchback or Sedan or SUV");
                }
                if (!(Regex.IsMatch(objCar.Engine, @"^\d\.\dL$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Engine name should have 4 characters with 1st and 3rd character number ,2nd '.' and last 'L'");
                }
                if (!(Regex.IsMatch(objCar.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("BHP should be a number");
                }
                if (objCar.Transmission!="Manual" && objCar.Transmission!="Automatic")
                {
                    valid = false;
                    errorMessage.AppendLine("Transmission type Should be either Manual or Automatic");
                }
                if (!(Regex.IsMatch(objCar.Mileage.ToString(), @"^[0-9]{2}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Mileage should be a number");
                }
                if (!(Regex.IsMatch(objCar.Seats.ToString(), @"^[0-9]{1}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("seats should be a number");
                }
                if (!(Regex.IsMatch(objCar.AirBagDetails, @"^[A-Za-z]+$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Airbags details should be a string");
                }
                if (!(Regex.IsMatch(objCar.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(objCar.Colour, @"^[A-Za-z]+$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Bootspace should be a number with 3 digits");
                }
                if (!(Regex.IsMatch(objCar.Price.ToString(), @"^[0-9]+$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Price should be a number");
                }                
                if (!valid)
                {
                    throw new CIMSException(errorMessage.ToString());
                }
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return valid;

        }
        public static CarDAL objCarDAL = new CarDAL();
        public static bool AddCarBAL(Car objCar)
        {
            bool carAdded;
            try
            {                
                carAdded= objCarDAL.AddCarDAL(objCar);
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carAdded;
        }
        public static bool  UpdateCarBAL(Car objCar)
        {
            bool carUpdated;
            try
            {
             carUpdated = objCarDAL.UpdateCarDAL(objCar) ;
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carUpdated;
        }
        public static bool DeleteCarBAL(string model)
        {
            bool carDeleted;
            try
            {
                carDeleted = objCarDAL.DeleteCarDAL(model); 
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carDeleted;
        }
        public static List<Car> SearchCarByNameBAL(string Name)
        {
            List<Car> objCars =null;
            try
            {
                objCars = objCarDAL.SearchCarByNameDAL(Name);
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objCars;
        }
        public static Car SearchCarByModelBAL(string model)
         {
          
            Car objCar = null;
            try
            {
                objCar = objCarDAL.SearchCarByModelDAL(model);
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objCar;
        }
        public static List<Car> GetListBAL()
        {
            List<Car> objCars = null;
            try
            {
                objCars = objCarDAL.GetListDAL();
            }
            catch (CIMSException objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objCars;
        }
    }
}
