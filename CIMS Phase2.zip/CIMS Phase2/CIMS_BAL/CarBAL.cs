﻿using CIMS_DAL;
using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS_BAL
{
    public class CarBAL
    {      
            public static CarDAL objCarDAL = new CarDAL();
            public static bool AddCarBAL(Car objCar)
            {
                bool carAdded;
                try
                {
                    carAdded = objCarDAL.AddCarDAL(objCar);
                }
                catch (CarExceptions objCarEx)
                {
                   throw objCarEx;
                }
                catch (Exception objEx)
                {
                throw objEx;
                }
                return carAdded;
            }
            public static bool UpdateCarBAL(Car objCar)
            {
                bool carUpdated;
                try
                {
                    carUpdated = objCarDAL.UpdateCarDAL(objCar);
                }
                catch (CarExceptions objCarEx)
                {
                    throw objCarEx;
                }
                catch (Exception objEx)
                {
                    throw objEx;
                }
                return carUpdated;
            }
            public static bool DeleteCarBAL(string model)
            {
                bool carDeleted;
                try
                {
                    carDeleted = objCarDAL.DeleteCarDAL(model);
                }
                catch (CarExceptions objCarEx)
                {
                     throw objCarEx;
                }
                catch (Exception objEx)
                {
                     throw objEx;
                }
                return carDeleted;
            }          
            public static Car SearchCarByModelBAL(string model)
            {

                Car objCar = null;
                try
                {
                    objCar = objCarDAL.SearchCarByModelDAL(model);
                }
                catch (CarExceptions objCarEx)
                {
                    throw objCarEx;
                }
                catch (Exception objEx)
                {
                    throw objEx;
                }
                return objCar;
            }
            public static Car SearchCarByNameBAL(string Name)
            {
                Car objCar = null;
                try
                {
                    objCar = objCarDAL.SearchCarByNameDAL(Name);
                }
                catch (CarExceptions objCarEx)
                {
                    throw objCarEx;
                }
                catch (Exception objEx)
                {
                    throw objEx;
                }
                return objCar;
            }
        public static List<Car> GetListBAL(string name, string type)
            {
                List<Car> objCars = null;
                try
                {
                    objCars = objCarDAL.ListAllCars(name,type);
                }
                catch (CarExceptions objCarEx)
                {
                    throw objCarEx;
                }
                catch (Exception objEx)
                {
                    throw objEx;
                }
                return objCars;
            }
        }
    }

