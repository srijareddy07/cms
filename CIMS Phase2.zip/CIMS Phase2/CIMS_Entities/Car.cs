﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS_Entities
{
    public class Car
    {
        public int ManufacturerName { get; set; }
        public string Model { get; set; }
        public int Type { get; set; }
        public string Engine { get; set; }
        public int BHP { get; set; }
        public int Transmission { get; set; }
        public int Mileage { get; set; }
        public int Seats { get; set; }
        public string AirBagDetails { get; set; }
        public int BootSpace { get; set; }
        public string Colour { get; set; }
        public double Price { get; set; }
    }
}
